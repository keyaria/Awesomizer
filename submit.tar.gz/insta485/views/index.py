"""
Insta485 index (main) view.

URLs include:
/
/p/<postid>/
"""
import os
import flask
import arrow
import insta485


def set_post(post, logname):
    """Set post dict."""
    post['img_url'] = '/uploads/'+post['filename']
    post['owner_img_url'] = '/uploads/' + \
        insta485.model.get_owner_img(post['owner'])
    post['likes'] = insta485.model.get_likes(post['postid'])
    post['timestamp'] = arrow.get(post['created']).humanize()
    post['comments'] = insta485.model.get_comments(post['postid'])
    post['loginlike'] = 'unlike' if \
        insta485.model.get_like_bylogname(post['postid'], logname) else 'like'


@insta485.app.route('/uploads/<path:filename>')
def get_image(filename):
    """Return image from static directory."""
    if not flask.session.get('username'):
        return flask.redirect(flask.url_for('login'))
    ul_folder = insta485.config.UPLOAD_FOLDER
    return flask.send_from_directory(ul_folder, filename, as_attachment=True)


@insta485.app.route('/', methods=['POST', 'GET'])
def show_index():
    """Display / route."""
    if not flask.session.get('username'):
        return flask.redirect(flask.url_for('login'))

    logname = flask.session.get('username')

    if flask.request.method == "POST":

        postid = flask.request.form.get("postid")

        if flask.request.form.get("like") is not None:
            insta485.model.set_like("like", postid, logname)
        elif flask.request.form.get("unlike") is not None:
            insta485.model.set_like("unlike", postid, logname)

        if flask.request.form.get("comment") is not None:
            temp_text = flask.request.form.get("text")
            insta485.model.set_comment(logname, postid, temp_text)

    context = {}
    context['logname'] = logname
    context['posts'] = insta485.model.get_posts_from_followers(logname)

    for post in context['posts']:
        set_post(post, context['logname'])

    return flask.render_template('index.html', **context)


@insta485.app.route('/p/<postid_str>/', methods=['POST', 'GET'])
def show_post(postid_str):
    """Display /p/<postid_str>/."""
    if not flask.session.get('username'):
        return flask.redirect(flask.url_for('login'))

    logname = flask.session.get('username')

    if flask.request.method == "POST":

        postid = flask.request.form.get("postid")
        commentid = flask.request.form.get("commentid")

        if flask.request.form.get("like") is not None:
            insta485.model.set_like("like", postid, logname)
        elif flask.request.form.get("unlike") is not None:
            insta485.model.set_like("unlike", postid, logname)

        if flask.request.form.get("uncomment") is not None:
            insta485.model.delete_comment(commentid, logname)

        if flask.request.form.get("delete") is not None:
            img_url = insta485.model.get_posts(int(postid_str))[0]['filename']
            os.remove(os.path.join(insta485.config.UPLOAD_FOLDER, img_url))
            insta485.model.delete_post(postid, logname)
            return flask.redirect(flask.url_for('show_index'))

        if flask.request.form.get("comment") is not None:
            temp_text = flask.request.form.get("text")
            insta485.model.set_comment(logname, postid, temp_text)

    context = insta485.model.get_posts(int(postid_str))[0]
    context['logname'] = logname
    set_post(context, logname)

    return flask.render_template("post.html", **context)
