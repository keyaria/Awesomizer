"""
Insta485 user view.

URLs include:
/u/<username>/
/u/followers/
/u/following/
"""
import hashlib
import shutil
import tempfile
import os
import flask
import insta485


def sha256sum(filename):
    """Return sha256 hash of file content, similar to UNIX sha256sum."""
    content = open(filename, 'rb').read()
    sha256_obj = hashlib.sha256(content)
    return sha256_obj.hexdigest()


@insta485.app.route('/u/<username_input>/', methods=['POST', 'GET'])
def username(username_input):
    """Show the user."""
    if not flask.session.get('username'):
        return flask.redirect(flask.url_for('login'))

    context = {}
    context["logname"] = flask.session.get('username')

    if flask.request.method == "POST":
        if flask.request.form.get("unfollow"):
            unfollowed_username = flask.request.form.get("username")
            insta485.model.delete_follower(context["logname"],
                                           unfollowed_username)
        elif flask.request.form.get("follow"):
            followed_username = flask.request.form.get("username")
            insta485.model.insert_follower(context["logname"],
                                           followed_username)

        else:
            # Save POST request's file object to a temp file
            dummy, temp_filename = tempfile.mkstemp()
            file_news = flask.request.files["file"]
            file_news.save(temp_filename)

            # Compute filename
            hash_txt = sha256sum(temp_filename)
            dummy, suffix = os.path.splitext(file_news.filename)
            hash_filename_basename = hash_txt + suffix
            hash_filenames = os.path.join(
                insta485.app.config["UPLOAD_FOLDER"],
                hash_filename_basename
            )

            # Move temp file to permanent location
            shutil.move(temp_filename, hash_filenames)
            insta485.app.logger.debug("Saved %s", hash_filename_basename)

            insta485.model.insert_new_post(hash_filename_basename,
                                           username_input)

    context["username"] = username_input
    context["fullname"] = insta485.model.get_fullname(username_input)
    context["total_posts"] = insta485.model.get_number_posts(username_input)
    context["followers"] = insta485.model.get_number_followers(username_input)
    context["following"] = insta485.model.get_number_following(username_input)
    context["posts"] = insta485.model.get_posts_by_username(username_input)
    context["logname_follows_username"] = insta485.model.\
        get_logname_follows_username(context["logname"], username_input)

    for post in context["posts"]:
        post['img_url'] = '/uploads/' + post['filename']

    return flask.render_template("user.html", **context)


@insta485.app.route('/u/<username_input>/followers/', methods=['POST', 'GET'])
def followers(username_input):
    """Show the followers."""
    if not flask.session.get('username'):
        return flask.redirect(flask.url_for('login'))

    context = {}
    context["logname"] = flask.session.get('username')

    if flask.request.method == "POST":
        if flask.request.form.get("unfollow"):
            unfollowed_username = flask.request.form.get("username")
            insta485.model.delete_follower(context["logname"],
                                           unfollowed_username)
        else:
            followed_username = flask.request.form.get("username")
            insta485.model.insert_follower(context["logname"],
                                           followed_username)

    context["followers"] = insta485.model.get_followers(username_input)
    for follower in context["followers"]:
        follower["user_img_url"] = '/uploads/' + insta485.model.\
            get_owner_img(follower["username"])
        follower["logname_follows_username"] = \
            insta485.model.get_logname_follows_username(context["logname"],
                                                        follower["username"])

    return flask.render_template("followers.html", **context)


@insta485.app.route('/u/<username_input>/following/', methods=['POST', 'GET'])
def following(username_input):
    """Show the following."""
    if not flask.session.get('username'):
        return flask.redirect(flask.url_for('login'))

    context = {}
    context["logname"] = flask.session.get('username')

    if flask.request.method == "POST":
        if flask.request.form.get("unfollow"):
            unfollowed_username = flask.request.form.get("username")
            insta485.model.delete_follower(context["logname"],
                                           unfollowed_username)
        else:
            followed_username = flask.request.form.get("username")
            insta485.model.insert_follower(context["logname"],
                                           followed_username)

    context["following"] = insta485.model.get_following(username_input)
    for follow in context["following"]:
        follow["user_img_url"] = '/uploads/' + \
                                insta485.model.get_owner_img(
                                    follow["username"])
        follow["logname_follows_username"] = \
            insta485.model.get_logname_follows_username(context["logname"],
                                                        follow["username"])
    return flask.render_template("following.html", **context)
