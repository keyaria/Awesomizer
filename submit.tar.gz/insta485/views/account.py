"""
Insta485 account view.

URLs include:
/accounts/login/
/accounts/logout/
/accounts/create/
/accounts/delete/
/accounts/edit/
/accounts/passwords/
"""
import os
import uuid
import hashlib
import shutil
import tempfile
import flask
import insta485


def hash_and_save_file():
    """Hash and save fille."""
    # Save POST request's file object to a temp file
    dummy, temp_filename = tempfile.mkstemp()
    file_new = flask.request.files["file"]
    file_new.save(temp_filename)

    # Compute filename
    hash_txt = sha256sum(temp_filename)
    dummy, suffix = os.path.splitext(file_new.filename)
    hash_filename_basename = hash_txt + suffix
    hash_filename = os.path.join(
        insta485.app.config["UPLOAD_FOLDER"],
        hash_filename_basename
    )
    # Move temp file to permanent location
    shutil.move(temp_filename, hash_filename)
    insta485.app.logger.debug("Saved %s", hash_filename_basename)
    return hash_filename_basename


def sha256sum(filename):
    """Return sha256 hash of file content, similar to UNIX sha256sum."""
    content = open(filename, 'rb').read()
    sha256_obj = hashlib.sha256(content)
    return sha256_obj.hexdigest()


def hashed_salted_password(password, salt=None):
    """Salt and hash password."""
    algorithm = 'sha512'
    new_salt = uuid.uuid4().hex
    if salt is not None:
        new_salt = salt
    hash_obj = hashlib.new(algorithm)
    password_salted = new_salt + password
    hash_obj.update(password_salted.encode('utf-8'))
    password_hash = hash_obj.hexdigest()
    password_db_string = "$".join([algorithm, new_salt, password_hash])
    return password_db_string


def get_salt_from_password(db_password):
    """Get salt from db password."""
    return db_password[db_password.find("$")+1:db_password.rfind("$")]


@insta485.app.route('/accounts/login/', methods=['POST', 'GET'])
def login():
    """Handle logging in."""
    if flask.request.method == 'POST':
        username = flask.request.form.get('username')
        submitted_password = flask.request.form.get('password')

        db_password = insta485.model.get_user_password(username)
        salt = get_salt_from_password(db_password['password'])
        password = hashed_salted_password(submitted_password, salt=salt)

        if password == db_password['password']:
            flask.session['username'] = username
            return flask.redirect(flask.url_for('show_index'))

    return flask.render_template("login.html")


@insta485.app.route('/accounts/logout/', methods=['POST', 'GET'])
def logout():
    """Handle logging out."""
    if not flask.session.get('username'):
        return flask.redirect(flask.url_for('login'))
    flask.session.pop('username')
    return flask.redirect(flask.url_for('login'))


@insta485.app.route('/accounts/create/', methods=['POST', 'GET'])
def create_account():
    """Handle creating account."""
    if flask.session.get('username'):
        return flask.redirect(flask.url_for('edit_account'))

    if flask.request.method == "POST":
        fullname = flask.request.form.get("fullname")
        username = flask.request.form.get("username")
        email = flask.request.form.get("email")
        password = flask.request.form.get("password")
        password = hashed_salted_password(password)

        hash_filename_basename = hash_and_save_file()
        insta485.model.insert_new_user(username, fullname, email,
                                       hash_filename_basename, password)

        flask.session['username'] = username
        return flask.redirect(flask.url_for('show_index'))

    return flask.render_template("create.html")


@insta485.app.route('/accounts/delete/', methods=['POST', 'GET'])
def delete_account():
    """Handle deleting account."""
    if not flask.session.get('username'):
        return flask.redirect(flask.url_for('login'))

    context = {}
    if flask.request.method == 'POST':
        username = flask.session.get('username')
        for post in insta485.model.get_posts_by_username(username):
            img_url = post['filename']
            os.remove(os.path.join(insta485.config.UPLOAD_FOLDER, img_url))

        old_img = insta485.model.get_owner_img(flask.session.get('username'))
        os.remove(os.path.join(insta485.config.UPLOAD_FOLDER, old_img))

        insta485.model.delete_account(flask.session.get('username'))
        flask.session.pop('username')
        return flask.redirect(flask.url_for('create_account'))

    context['logname'] = flask.session.get('username')
    return flask.render_template("delete.html", **context)


@insta485.app.route('/accounts/edit/', methods=['POST', 'GET'])
def edit_account():
    """Handle editting account."""
    if not flask.session.get('username'):
        return flask.redirect(flask.url_for('login'))

    if flask.request.method == 'POST':
        filename = flask.request.files.get('file', None)
        fullname = flask.request.form['fullname']
        email = flask.request.form['email']

        hash_filename_basename = None
        if filename is not None:
            hash_filename_basename = hash_and_save_file()
            old_img = insta485.model.get_owner_img(flask.session.get(
                'username'))
            os.remove(os.path.join(insta485.config.UPLOAD_FOLDER, old_img))

        username = flask.session.get('username')
        insta485.model.update_user_info(username,
                                        hash_filename_basename,
                                        email, fullname)

    context = {}
    user_info = insta485.model.get_user_info(flask.session.get('username'))
    context['logname'] = user_info['username']
    context['email'] = user_info['email']
    context['logname_img_url'] = user_info['filename']
    context['fullname'] = user_info['fullname']
    return flask.render_template("edit.html", **context)


@insta485.app.route('/accounts/password/', methods=['POST', 'GET'])
def change_password():
    """Handle changing password."""
    if not flask.session.get('username'):
        return flask.redirect(flask.url_for('login'))

    if flask.request.method == 'POST':
        old_password = flask.request.form.get('password')
        new_password1 = flask.request.form.get('new_password1')
        new_password2 = flask.request.form.get('new_password2')

        if new_password1 != new_password2:
            flask.abort(401)

        username = flask.session.get('username')
        db_password = insta485.model.get_user_password(username)
        salt = get_salt_from_password(db_password['password'])
        password = hashed_salted_password(old_password, salt=salt)

        if password != db_password['password']:
            flask.abort(403)

        new_password = hashed_salted_password(new_password1)
        insta485.model.update_user_password(new_password, username)
        return flask.redirect(flask.url_for('edit_account'))

    context = {}
    context['logname'] = flask.session.get('username')
    return flask.render_template("change.html", **context)
