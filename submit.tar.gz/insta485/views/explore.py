"""
Insta485 explore view.

URLs include:
/explore/
"""
import flask
import insta485


@insta485.app.route('/explore/', methods=['POST', 'GET'])
def show_explore():
    """Show the explore.html file."""
    if not flask.session.get('username'):
        return flask.redirect(flask.url_for('login'))

    context = {}
    context["logname"] = flask.session.get('username')
    if flask.request.method == "POST":
        if flask.request.form.get("follow"):
            followed_username = flask.request.form.get("username")
            insta485.model.insert_follower(context["logname"],
                                           followed_username)

    context["not_following"] = \
        insta485.model.get_non_followers(context["logname"])
    for non in context["not_following"]:
        non["username"] = insta485.model.get_username(non["username"])
        non["user_img_url"] = '/uploads/' + \
                              insta485.model.get_owner_img(non["username"])
    return flask.render_template("explore.html", **context)
