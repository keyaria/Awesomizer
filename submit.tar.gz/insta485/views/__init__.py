"""Views, one for each Insta485 page."""
from insta485.views.index import show_index, show_post
from insta485.views.account import login, logout, create_account, \
    delete_account, edit_account, change_password
from insta485.views.user import username, followers, following
from insta485.views.explore import show_explore
