"""Rest API for returning details for one post."""
import flask
import insta485
from insta485.api.error_handler import InvalidUsage


@insta485.app.route('/api/v1/p/<int:postid_url_slug>/', methods=["GET"])
def get_post(postid_url_slug):
    """Get details for one post."""
    if not flask.session.get('username'):
        raise InvalidUsage('Forbidden', status_code=403)

    #number_posts = len(insta485.model.get_posts())

    #if postid_url_slug > number_posts:
        #raise InvalidUsage('Not Found', status_code=404)

    if not insta485.model.is_valid_id(type_="post", postid=postid_url_slug):
        raise InvalidUsage('Not Found', status_code=404)

    context = {}
    post = insta485.model.get_posts(postid_url_slug)[0]

    context["age"] = post["created"]
    context["img_url"] = "/uploads/" + post["filename"]
    context["owner"] = post["owner"]
    context["owner_img_url"] = "/uploads/" + \
                               insta485.model.get_owner_img(post["owner"])
    context["owner_show_url"] = "/u/" + post["owner"] + "/"
    context["post_show_url"] = "/p/" + str(postid_url_slug) + "/"
    context["url"] = flask.request.path
    return flask.jsonify(**context)
