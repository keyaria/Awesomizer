"""REST API for services."""
import flask
import insta485
from insta485.api.error_handler import InvalidUsage


@insta485.app.route('/api/v1/p/', methods=["GET"])
def get_posts():
    """Return list of posts."""
    if not flask.session.get('username'):
        raise InvalidUsage('Forbidden', status_code=403)

    context = {}
    size = flask.request.args.get("size", default=10, type=int)
    page_number = flask.request.args.get("page", default=0, type=int)
    if page_number < 0 or size < 0:
        raise InvalidUsage("Bad Request", status_code=400)

    username = flask.session.get("username")
    offset = size * page_number

    posts = insta485.model.get_posts_limit_offset(
        username, size, offset)

    total_posts = insta485.model.followers_posts_count(username)

    context["next"] = ""
    context["results"] = []

    if (page_number + 1) * size < total_posts[0]["count"]:
        context["next"] = "/api/v1/p/?size=" + str(size) + "&page=" + \
                          str(page_number + 1)

    for post in posts:
        dic = {
            "postid": int(post["postid"]),
            "url": "/api/v1/p/{}/".format(post["postid"])
            }
        context["results"].append(dic)

    context["url"] = "/api/v1/p/"

    return flask.jsonify(**context)
