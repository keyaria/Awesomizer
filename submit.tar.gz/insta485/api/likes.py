"""REST API for likes."""
import flask
import insta485
from insta485.api.error_handler import InvalidUsage
'''
    size = flask.request.args.get("size", default=10, type=int)
    page_number = flask.request.args.get("page", default=0, type=int)

    if page_number < 0 or size < 0:
        raise InvalidUsage("Bad Request", status_code=400)
'''

@insta485.app.route('/api/v1/p/<int:postid_url_slug>/likes/', methods=["GET", "DELETE", "POST"])
def get_likes(postid_url_slug):
    """Return likes on postid."""
    if not flask.session.get('username'):
        raise InvalidUsage('Forbidden', status_code=403)

    if not insta485.model.is_valid_id(type_="post", postid=postid_url_slug):
        raise InvalidUsage('Not Found', status_code=404)

    # User
    logname = flask.session["username"]
    context = {}

    # Post
    postid = postid_url_slug
    context["postid"] = postid

    # Did this user like this post?
    connection = insta485.model.get_db()
    cur = connection.execute(
        "SELECT EXISTS( "
        "  SELECT 1 FROM likes "
        "    WHERE postid = ? "
        "    AND owner = ? "
        "    LIMIT 1"
        ") AS logname_likes_this ",
        (postid, logname)
    )
    logname_likes_this = cur.fetchone()
    # Likes
    cur = connection.execute(
        "SELECT COUNT(*) AS likes_count FROM likes WHERE postid = ? ",
        (postid,)
    )
    likes_count = cur.fetchone()

    if flask.request.method == "GET":
        # url
        context["url"] = flask.request.path
        context.update(logname_likes_this)
        context.update(likes_count)
        return flask.jsonify(**context)

    elif flask.request.method == "POST":
        context["logname"] = logname
        if(logname_likes_this['logname_likes_this'] != 1):
            insta485.model.set_like('like', postid, logname)
            return flask.jsonify(**context), 201
        else:
            context['message'] = "Conflict"
            context['status_code'] = 409
            return flask.jsonify(**context), 409

    elif flask.request.method == "DELETE":
        insta485.model.set_like('unlike', postid, logname)
        return flask.jsonify(**{}), 204

    else:
        raise InvalidUsage("Bad Request", status_code=400)
