"""Insta485 REST API."""

from insta485.api.likes import get_likes
from insta485.api.posts import get_posts
from insta485.api.comments import get_comments
from insta485.api.post_metadata import get_post
from insta485.api.services import get_services
