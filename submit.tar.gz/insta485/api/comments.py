"""Rest API for returning comments for one post."""
import flask
import insta485
from insta485.api.error_handler import InvalidUsage


@insta485.app.route('/api/v1/p/<int:postid_url_slug>/comments/', methods=[
    "GET", "POST"])
def get_comments(postid_url_slug):
    """Get comments according to rest API."""
    if not flask.session.get('username'):
        raise InvalidUsage('Forbidden', status_code=403)

    if not insta485.model.is_valid_id(type_="post", postid=postid_url_slug):
        raise InvalidUsage('Not Found', status_code=404)

    #number_posts = len(insta485.model.get_posts())
    #if postid_url_slug > number_posts:
        #raise InvalidUsage('Not Found', status_code=404)

    context = {}

    if flask.request.method == "POST":
        logname = flask.session.get("username")
        insta485.model.set_comment(logname, postid_url_slug,
                                   flask.request.json['text'])
        context["commentid"] = insta485.model.get_last_inserted_comment()
        context["owner"] = logname
        context["owner_show_url"] = '/u/' + logname + '/'
        context["postid"] = postid_url_slug
        context["text"] = flask.request.json["text"]
        return flask.jsonify(**context), 201

    elif flask.request.method == "GET":
        logname = flask.session.get("username")

        comments = []
        for comment in insta485.model.get_comments(postid_url_slug):
            modified_comment = {}
            modified_comment["commentid"] = comment["commentid"]
            modified_comment["owner"] = comment["owner"]
            modified_comment["owner_show_url"] = '/u/' + comment['owner'] + '/'
            modified_comment["postid"] = postid_url_slug
            modified_comment["text"] = comment["text"]
            comments.append(modified_comment)
        context["comments"] = comments
        context["url"] = flask.request.path

    return flask.jsonify(**context)
