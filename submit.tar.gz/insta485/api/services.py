"""REST API for services."""
import flask
import insta485
from insta485.api.error_handler import InvalidUsage


@insta485.app.route('/api/v1/', methods=["GET"])
def get_services():
    """
    Return list of services available.

    Example:
    {
        "posts": "/api/v1/p/",
        "url": "/api/v1/"
    }
    """
    if not flask.session.get('username'):
        raise InvalidUsage('Forbidden', status_code=403)

    context = {
        "posts": "/api/v1/p/",
        "url": "/api/v1/"
        }

    return flask.jsonify(**context)
