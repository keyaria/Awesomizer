"""Insta485 model (database) API."""
import sqlite3
import flask
import insta485


def dict_factory(cursor, row):
    """
    Convert database row objects to a dictionary.

    This is useful for building dictionaries which are then
    used to render a template.  Note that
    this would be inefficient for large queries.
    """
    output = {}
    for idx, col in enumerate(cursor.description):
        output[col[0]] = row[idx]
    return output


def get_db():
    """Open a new database connection."""
    if not hasattr(flask.g, 'sqlite_db'):
        flask.g.sqlite_db = sqlite3.connect(
            insta485.app.config['DATABASE_FILENAME'])
        flask.g.sqlite_db.row_factory = dict_factory

        # Foreign keys have to be enabled per-connection.  This is an sqlite3
        # backwards compatibility thing.
        flask.g.sqlite_db.execute("PRAGMA foreign_keys = ON")

    return flask.g.sqlite_db


@insta485.app.teardown_appcontext
def close_db(error):
    # pylint: disable=unused-argument
    """Close the database at the end of a request."""
    if hasattr(flask.g, 'sqlite_db'):
        flask.g.sqlite_db.commit()
        flask.g.sqlite_db.close()


def get_user_password(username):
    """Get user's password."""
    cur = get_db().execute("SELECT password FROM users WHERE username = (?)",
                           [username])
    res = cur.fetchone()
    return res


def insert_new_user(username, fullname, email, filename, password):
    """Add user to database."""
    database = get_db()
    database.execute(
        "INSERT INTO users (username, fullname, email, filename, "
        "password) "
        "VALUES (?, ?, ?, ?, ?)",
        [username, fullname, email, filename, password])
    database.commit()


def get_byid(table, postid):
    """Help function for getting table by postid."""
    database = get_db()
    if postid is None:
        cur = database.execute(
            "SELECT * FROM " + table +
            " ORDER BY datetime("+table+".created)")
    else:
        cur = database.execute(
            "SELECT * FROM "+table+" WHERE postid = (?) "
            " ORDER BY datetime("+table+".created)",
            [postid])
    return cur.fetchall()


def get_likes(postid=None):
    """Get likes for a post."""
    return len(get_byid("likes", postid))


def get_like_bylogname(postid, logname):
    """Get like by postid and logname."""
    cur = get_byid('likes', postid)
    for owner in cur:
        if owner['owner'] == logname:
            return True
    return False


def set_like(action, postid, logname):
    """Set and Remove likes from db by action, postid, and logged in user."""
    database = get_db()
    if action == "like":
        database.execute(
            "INSERT INTO likes (postid, owner) "
            "VALUES (?, ?)",
            [postid, logname])
    elif action == "unlike":
        database.execute(
            "DELETE FROM likes WHERE postid = (?) AND owner = (?)",
            [postid, logname])
    database.commit()


def get_posts(postid=None):
    """Get posts by postid."""
    return get_byid("posts", postid)


def delete_post(postid, owner):
    """Delete post."""
    database = get_db()
    database.execute(
        "DELETE FROM posts WHERE postid = (?) AND owner = (?)",
        [postid, owner])
    database.commit()


def get_comments(postid=None):
    """Get all comments for a post."""
    return get_byid("comments", postid)


def set_comment(owner, postid, text):
    """Add comment db."""
    database = get_db()
    database.execute(
        "INSERT INTO comments (owner, postid, text) "
        "VALUES (?, ?, ?)",
        [owner, postid, text])
    database.commit()


def delete_comment(commentid, owner):
    """Delete comment from db."""
    database = get_db()
    database.execute(
        "DELETE FROM comments "
        "WHERE commentid = (?) AND owner = (?)",
        [commentid, owner])
    database.commit()


def get_owner_img(owner):
    """Get img for owner."""
    database = get_db()
    cur = database.execute(
        "SELECT filename FROM users WHERE username = (?)",
        [owner])
    return cur.fetchone()["filename"]


def get_number_posts(username):
    """Get number of posts from username."""
    result = get_db().execute("SELECT COUNT(*) FROM posts WHERE owner = (?)",
                              [username]).fetchone()
    return result["COUNT(*)"]


def get_number_followers(username):
    """Get number of followers based on username."""
    result = get_db().execute("SELECT COUNT(*) FROM following WHERE "
                              "username2 = (?)", [username]).fetchone()
    return result["COUNT(*)"]


def get_number_following(username):
    """Get number of following based on username."""
    result = get_db().execute("SELECT COUNT(*) FROM following "
                              "WHERE username1 = (?)", [username]).fetchone()
    return result["COUNT(*)"]


def insert_new_post(filename, username):
    """Insert post in db."""
    database = get_db()
    database.execute(
        "INSERT INTO posts (filename, owner) "
        "VALUES (?,?)", [filename, username])
    database.commit()


def get_posts_by_username(username):
    """Get posts from user."""
    posts_list = get_db().execute("SELECT postid, "
                                  "filename FROM posts WHERE owner = (?)",
                                  [username]).fetchall()
    return posts_list


def get_fullname(username):
    """Get fullname of user."""
    result = get_db().execute("SELECT fullname "
                              "FROM users "
                              "WHERE username = (?)", [username]).fetchone()
    return result["fullname"]


def get_followers(username):
    """Get followers from username."""
    result = get_db().execute("SELECT username1"
                              " AS username "
                              "FROM following "
                              "WHERE username2 = (?)", [username]).fetchall()
    return result


def get_non_followers(username):
    """Get list of people not following from user."""
    result_following_list = get_following(username)
    result_all_users_list = get_db().execute("SELECT username "
                                             "FROM users "
                                             "WHERE username != (?)",
                                             [username]).fetchall()

    return [result for result in result_following_list+result_all_users_list
            if (result not in result_following_list)
            or (result not in result_all_users_list)]


def get_following(username):
    """Get folllowing from user."""
    result = get_db().execute("SELECT username2 "
                              "AS username "
                              "FROM following "
                              "WHERE username1 = (?)", [username])
    return result.fetchall()


def get_logname_follows_username(logname, username):
    """Get logname follows username."""
    cur = get_db().execute("SELECT * "
                           "FROM following "
                           "WHERE username1 = (?) "
                           "AND username2 = (?)", [logname, username])
    result_list = cur.fetchall()
    if result_list == []:
        return False
    return True


def get_username(username):
    """Get username from username."""
    result = get_db().execute("SELECT username "
                              "FROM users "
                              "WHERE username = (?)", [username]).fetchone()
    return result["username"]


def delete_follower(logname, unfollowed_username):
    """Delete follower."""
    get_db().execute("DELETE FROM following "
                     "WHERE username1 = (?) "
                     "AND username2 = (?)", [logname, unfollowed_username])


def insert_follower(logname, followed_username):
    """Insert follower."""
    database = get_db()
    database.execute(
        "INSERT INTO following (username1, username2) "
        "VALUES (?,?)", [logname, followed_username])
    database.commit()


def delete_account(username):
    """Delete user account."""
    get_db().execute(
        "DELETE FROM users WHERE username = (?)",
        [username])


def get_user_info(username):
    """Get user info."""
    result = get_db().execute("SELECT * FROM users WHERE username = (?)",
                              [username])
    return result.fetchone()


def update_user_info(username, filename, email, fullname):
    """Update user info."""
    database = get_db()
    if filename is None:
        database.execute(
            "UPDATE users SET email = (?),fullname = (?) "
            "WHERE username = (?)",
            [email, fullname, username])
        return
    else:
        database.execute(
            "UPDATE users SET email = (?),fullname = (?), "
            "filename = (?) "
            "WHERE username = (?)",
            [email, fullname, filename, username])


def update_user_password(password, username):
    """Update user password."""
    database = get_db()
    database.execute(
        "UPDATE users SET password = (?) WHERE username = (?)",
        [password, username])


def get_posts_from_followers(username):
    """Get posts from followers of user."""
    database = get_db()
    res = database.execute(
        "SELECT DISTINCT posts.postid, posts.filename, "
        "posts.owner, posts.created "
        "FROM posts, following "
        "WHERE (following.username1 = (?) "
        "AND posts.owner = following.username2) "
        "OR posts.owner = (?) "
        "ORDER BY datetime(posts.created) DESC",
        [username, username])
    return res.fetchall()


def get_posts_limit_offset(username, limit, offset):
    """Get posts from followers of user."""
    database = get_db()
    res = database.execute(
        "SELECT DISTINCT posts.postid "
        "FROM posts, following "
        "WHERE (following.username1 = (?) "
        "AND posts.owner = following.username2) "
        "OR posts.owner = (?) "
        "ORDER BY datetime(posts.created) DESC, "
        "posts.postid DESC "
        "LIMIT (?) OFFSET (?)",
        [username, username, limit, offset])
    return res.fetchall()


def followers_posts_count(username):
    """Get number of posts from followers of user."""
    database = get_db()
    res = database.execute(
        "SELECT COUNT(DISTINCT posts.postid) "
        "AS count "
        "FROM posts, following "
        "WHERE (following.username1 = (?) "
        "AND posts.owner = following.username2) "
        "OR posts.owner = (?) "
        "ORDER BY datetime(posts.created) DESC ",
        [username, username])
    return res.fetchall()


def get_last_inserted_comment():
    """Get the comment id for the last inserted comment."""
    database = get_db()
    result = database.execute("SELECT last_insert_rowid()")
    return result.fetchone()["last_insert_rowid()"]

def is_valid_id(type_, postid=None, commentid=None):
    database = get_db()
    if type_ == 'comment':
        cur = database.execute("SELECT * FROM comments WHERE postid = (?) AND commentid = (?)", [postid, commentid])
    elif type_ == 'post':
        cur = database.execute("SELECT * FROM posts WHERE postid = (?)", [postid])
    if(len(cur.fetchall())>0):
        return True
    else:
        return False
